<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'dayflow_hrms');
define('DB_USER', 'root');
define('DB_PASS', '');
define('APP_SECRET', 'change_this_secret');
